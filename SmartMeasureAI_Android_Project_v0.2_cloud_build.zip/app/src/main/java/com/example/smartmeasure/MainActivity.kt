package com.example.smartmeasure
import android.Manifest
import android.content.pm.PackageManager
import android.graphics.*
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale
import kotlin.math.hypot

class MainActivity : AppCompatActivity() {
 private lateinit var preview: PreviewView
 private lateinit var overlay: MeasureOverlay
 private lateinit var status: TextView
 private lateinit var calibrationInput: EditText
 private var pixelsPerCm: Float? = null
 private var calibrationStart: PointF? = null
 private var calibrating = false
 private var knownCm = 0f
 private val points = mutableListOf<PointF>()
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); buildUi()
  if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED) startCamera()
  else ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.CAMERA),10)
 }
 private fun buildUi() {
  val root=LinearLayout(this).apply { orientation=1; setBackgroundColor(Color.rgb(15,25,34)) }
  root.addView(TextView(this).apply { text="SmartMeasure AI • متر هوشمند"; textSize=20f; setTextColor(-1); gravity=Gravity.CENTER; setPadding(8,16,8,12) })
  preview=PreviewView(this).apply { scaleType=PreviewView.ScaleType.FILL_CENTER }
  val frame=FrameLayout(this); frame.addView(preview,FrameLayout.LayoutParams(-1,-1))
  overlay=MeasureOverlay(); frame.addView(overlay,FrameLayout.LayoutParams(-1,-1)); root.addView(frame,LinearLayout.LayoutParams(-1,0,1f))
  calibrationInput=EditText(this).apply { hint="طول مرجع به سانتی‌متر (مثلاً 10)"; setTextColor(-1); setHintTextColor(-3355444); inputType=2 or 8192 }
  root.addView(calibrationInput)
  val row=LinearLayout(this).apply { gravity=Gravity.CENTER }
  row.addView(Button(this).apply { text="کالیبراسیون"; setOnClickListener { val n=calibrationInput.text.toString().toFloatOrNull(); if(n==null||n<=0) status.text="طول مرجع را وارد کن" else { knownCm=n; points.clear(); calibrating=true; calibrationStart=null; status.text="دو سر مرجع را روی تصویر لمس کن" } } })
  row.addView(Button(this).apply { text="اندازه‌گیری"; setOnClickListener { calibrating=false; points.clear(); status.text="ابتدا و انتهای جسم را لمس کن" } })
  row.addView(Button(this).apply { text="پاک‌کردن"; setOnClickListener { points.clear(); overlay.invalidate(); status.text="پاک شد" } })
  root.addView(row)
  status=TextView(this).apply { text="با یک مرجع دارای اندازه معلوم کالیبره کن."; setTextColor(-1); gravity=Gravity.CENTER; setPadding(12,10,12,16) }; root.addView(status)
  setContentView(root)
 }
 private fun startCamera(){ val f=ProcessCameraProvider.getInstance(this); f.addListener({ val p=f.get(); val req=Preview.Builder().build().also{it.setSurfaceProvider(preview.surfaceProvider)}; try{p.unbindAll();p.bindToLifecycle(this,CameraSelector.DEFAULT_BACK_CAMERA,req)}catch(e:Exception){status.text="خطای دوربین: ${e.localizedMessage}"} },ContextCompat.getMainExecutor(this)) }
 override fun onRequestPermissionsResult(r:Int,p:Array<out String>,g:IntArray){super.onRequestPermissionsResult(r,p,g);if(r==10&&g.firstOrNull()==PackageManager.PERMISSION_GRANTED)startCamera() else status.text="دسترسی دوربین لازم است"}
 private inner class MeasureOverlay:View(this){
  private val paint=Paint(3)
  init{setOnTouchListener{_,e->if(e.action==MotionEvent.ACTION_DOWN){val q=PointF(e.x,e.y)
   if(calibrating){if(calibrationStart==null){calibrationStart=q;status.text="سر دوم مرجع را لمس کن"}else{val px=dist(calibrationStart!!,q);if(px>2){pixelsPerCm=px/knownCm;status.text=String.format(Locale.US,"کالیبراسیون: %.2f px/cm",pixelsPerCm)};calibrating=false;calibrationStart=null}}
   else{points.add(q);if(points.size==2){val s=pixelsPerCm;if(s==null)status.text="اول کالیبراسیون کن" else{val cm=dist(points[0],points[1])/s;status.text=String.format(Locale.US,"طول تقریبی %.1f cm (%.3f m)",cm,cm/100)}}else if(points.size>2){points.clear();points.add(q)}}
   invalidate();true}else false}}
  override fun onDraw(c:Canvas){super.onDraw(c);paint.color=Color.YELLOW;paint.strokeWidth=5f;paint.style=Paint.Style.STROKE;if(points.size>=2)c.drawLine(points[0].x,points[0].y,points[1].x,points[1].y,paint);paint.style=Paint.Style.FILL;points.forEach{c.drawCircle(it.x,it.y,9f,paint)};calibrationStart?.let{c.drawCircle(it.x,it.y,10f,paint)}}
 }
 private fun dist(a:PointF,b:PointF)=hypot(a.x-b.x,a.y-b.y)
}
